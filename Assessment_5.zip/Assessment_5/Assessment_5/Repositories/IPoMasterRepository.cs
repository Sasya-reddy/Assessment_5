﻿using Assessment_5.Entities;

namespace Assessment_5.Repositories
{
    public interface IPoMasterRepository
    {
        Task<List<PoMaster>> GetAllAsync();
        Task<PoMaster> GetByIdAsync(string id);
        Task AddAsync(PoMaster poMaster);
        Task UpdateAsync(PoMaster poMaster);
        Task DeleteAsync(string id);
    }
}
