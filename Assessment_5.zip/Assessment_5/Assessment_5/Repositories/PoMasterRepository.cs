﻿using Assessment_5.Entities;
using Microsoft.EntityFrameworkCore;

namespace Assessment_5.Repositories
{
    public class PoMasterRepository : IPoMasterRepository
    {
        private readonly PODbContext _context;
        private IConfiguration _configuration;
        public PoMasterRepository(PODbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task AddAsync(PoMaster poMaster)
        {
            await _context.PoMasters.AddAsync(poMaster);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(string id)
        {
            var poMaster = await GetByIdAsync(id);
            _context.PoMasters.Remove(poMaster);
            await _context.SaveChangesAsync();

        }

        public async Task<List<PoMaster>> GetAllAsync()
        {
            return await _context.PoMasters.ToListAsync();
        }

        public async Task<PoMaster> GetByIdAsync(string id)
        {
            return await _context.PoMasters.FindAsync(id);
        
        }

        public async Task UpdateAsync(PoMaster poMaster)
        {
            _context.Entry(poMaster).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}
