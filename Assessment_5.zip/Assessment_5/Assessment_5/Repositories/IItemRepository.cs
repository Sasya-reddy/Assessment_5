﻿using Assessment_5.Entities;

namespace Assessment_5.Repositories
{
    public interface IItemRepository
    {
        Task<List<Item>> GetAllAsync();
        Task<Item> GetByIdAsync(string id);
        Task AddAsync(Item item);
        Task UpdateAsync(Item item);
        Task DeleteAsync(string id);
    }
}
