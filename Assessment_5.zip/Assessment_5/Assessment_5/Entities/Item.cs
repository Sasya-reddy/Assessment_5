﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Assessment_5.Entities
{
    public class Item
    {
        [Key]
        [StringLength(4)]
        public string ItCode { get; set; }

        [Required]
        [StringLength(15)]
        public string ItDesc { get; set; }
        [Column(TypeName = "money")]

        public decimal ItRate { get; set; }
    }
}
