﻿using Microsoft.EntityFrameworkCore;

namespace Assessment_5.Entities
{
    public class PODbContext:DbContext
    {
        private readonly IConfiguration obj;
        public PODbContext(IConfiguration configuration)
        {
            obj = configuration;
        }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<PoMaster>  PoMasters{ get; set; }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // optionsBuilder.UseSqlServer("Data Source=DESKTOP-MMAT251\\SQLEXPRESS01;Initial Catalog=Ecomm;Integrated Security=True;Trust Server Certificate=True\r\n");
            optionsBuilder.UseSqlServer(obj.GetConnectionString("PODbConnection"));
        }

    }
}
