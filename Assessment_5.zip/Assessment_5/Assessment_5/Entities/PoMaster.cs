﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Assessment_5.Entities
{
    public class PoMaster
    {
        [Key]
        [StringLength(4)]
        public string PoNo { get; set; }

        public DateTime PoDate { get; set; }

        [ForeignKey("Item")]
        public string ItCode { get; set; }
        [JsonIgnore]
        public Item? Item { get; set; }

        public int Qty { get; set; }

        [ForeignKey("Supplier")]
        
        public string SuplNo { get; set; }
        [JsonIgnore]
        public Supplier? Supplier { get; set; }
        //[ForeignKey("Category")]
        //public string CategoryId { get; set; }
        //[JsonIgnore]
        //public Category? Category { get; set; }
    }
}
