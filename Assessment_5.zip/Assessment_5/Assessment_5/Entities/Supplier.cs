﻿using System.ComponentModel.DataAnnotations;

namespace Assessment_5.Entities
{
    public class Supplier
    {
        [Key]
        [StringLength(4)]
        public string SuplNo { get; set; }

        [Required]
        [StringLength(15)]
        public string SuplName { get; set; }

        [StringLength(40)]
        public string SuplAddr { get; set; }
    }
}
