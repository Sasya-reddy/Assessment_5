﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assessment_5.Migrations
{
    /// <inheritdoc />
    public partial class mig3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    ItCode = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: false),
                    ItDesc = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    ItRate = table.Column<decimal>(type: "money", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.ItCode);
                });

            migrationBuilder.CreateTable(
                name: "Suppliers",
                columns: table => new
                {
                    SuplNo = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: false),
                    SuplName = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    SuplAddr = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suppliers", x => x.SuplNo);
                });

            migrationBuilder.CreateTable(
                name: "PoMasters",
                columns: table => new
                {
                    PoNo = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: false),
                    PoDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ItCode = table.Column<string>(type: "nvarchar(4)", nullable: false),
                    Qty = table.Column<int>(type: "int", nullable: false),
                    SuplNo = table.Column<string>(type: "nvarchar(4)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PoMasters", x => x.PoNo);
                    table.ForeignKey(
                        name: "FK_PoMasters_Items_ItCode",
                        column: x => x.ItCode,
                        principalTable: "Items",
                        principalColumn: "ItCode",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PoMasters_Suppliers_SuplNo",
                        column: x => x.SuplNo,
                        principalTable: "Suppliers",
                        principalColumn: "SuplNo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PoMasters_ItCode",
                table: "PoMasters",
                column: "ItCode");

            migrationBuilder.CreateIndex(
                name: "IX_PoMasters_SuplNo",
                table: "PoMasters",
                column: "SuplNo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PoMasters");

            migrationBuilder.DropTable(
                name: "Items");

            migrationBuilder.DropTable(
                name: "Suppliers");
        }
    }
}
