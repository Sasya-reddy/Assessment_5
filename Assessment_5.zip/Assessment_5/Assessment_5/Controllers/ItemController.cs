﻿using Assessment_5.Entities;
using Assessment_5.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assessment_5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemRepository _itemRepository;
        private readonly IConfiguration _configuration;
        public ItemController(IItemRepository itemRepository, IConfiguration configuration)
        {
            _itemRepository = itemRepository;
            _configuration = configuration;
        }
        [HttpGet, Route("GetItems")]
        public async Task<ActionResult<IEnumerable<Item>>> GetItems()
        {
            var items = await _itemRepository.GetAllAsync();
            return Ok(items);
        }

        [HttpGet, Route("GetById")]
        public async Task<ActionResult<Item>> GetItem(string id)
        {
            var item = await _itemRepository.GetByIdAsync(id);
            return Ok(item);
        }
        [HttpPost, Route("AddItem")]
        public async Task<ActionResult<Item>> AddItem(Item item)
        {
            await _itemRepository.AddAsync(item);
            return Ok(item);
        }
        [HttpPut, Route("UpdateItem")]
        public async Task<IActionResult> EditItem(string id, Item item)
        {
            await _itemRepository.UpdateAsync(item);
            return Ok(item);
        }
        [HttpDelete, Route("DeleteItem")]
        public async Task<IActionResult> DeleteAsync(string id)
        {
            await _itemRepository.DeleteAsync(id);
            return Ok();
        }

    }
}
