﻿using Assessment_5.Entities;
using Assessment_5.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assessment_5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISupplierRepository _supplierRepository;
        private readonly IConfiguration _configuration;
        public SupplierController(ISupplierRepository supplierRepository, IConfiguration configuration)
        {
            _supplierRepository = supplierRepository;
            _configuration = configuration;
        }
        
        [HttpGet,Route("GetSuppliers")]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetSuppliers()
        {
            var suppliers = await _supplierRepository.GetAllAsync();
            return Ok(suppliers);
        }
        [HttpGet,Route("GetById")]
        public async Task<ActionResult<Supplier>> GetSupplier(string id)
        {
            var supplier = await _supplierRepository.GetByIdAsync(id);

            if (supplier == null)
            {
                return NotFound();
            }

            return Ok(supplier);
        }
        [HttpPost,Route("AddSupplier")]
        public async Task<ActionResult<Supplier>> AddSupplier(Supplier supplier)
        {        
            await _supplierRepository.AddAsync(supplier);
            return Ok(supplier);
        }
        [HttpPut,Route("UpdateSupplier")]
        public async Task<IActionResult> EditSupplier(string id, Supplier supplier)
        {
            await _supplierRepository.UpdateAsync(supplier);
            return Ok(supplier);
        }
        [HttpDelete, Route("DeleteCategory")]
        public async Task<IActionResult> DeleteAsync(string id)
        {
            await _supplierRepository.DeleteAsync(id);
            return Ok();
        }





    }
}
