﻿using Assessment_5.Entities;
using Assessment_5.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assessment_5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PoMasterController : ControllerBase
    {
        private readonly IPoMasterRepository _poMasterRepository;
        private readonly IConfiguration _configuration;
        public PoMasterController(IPoMasterRepository poMasterRepository, IConfiguration configuration)
        {
            _poMasterRepository = poMasterRepository;
            _configuration = configuration;
        }
        [HttpGet,Route("GetAll")]
        public async Task<ActionResult<IEnumerable<PoMaster>>> GetPoMasters()
        {
            var poMasters = await _poMasterRepository.GetAllAsync();
            return Ok(poMasters);
        }
        [HttpGet,Route("GetById")]
        public async Task<ActionResult<PoMaster>> GetPoMaster(string id)
        {
            var poMaster = await _poMasterRepository.GetByIdAsync(id);
            return Ok(poMaster);
        }
        [HttpPost,Route("AddPoMaster")]
        public async Task<ActionResult<PoMaster>> PostPoMaster(PoMaster poMaster)
        {         
            await _poMasterRepository.AddAsync(poMaster);
            return Ok(poMaster);
        }
        [HttpPut,Route("EditPoMaster")]
        public async Task<IActionResult> EditPoMaster(string id, PoMaster poMaster)
        {
            await _poMasterRepository.UpdateAsync(poMaster);
            return NoContent();
        }
        [HttpDelete,Route("DeletePoMaster")]
        public async Task<IActionResult> DeletePoMaster(string id)
        {
            var poMaster = await _poMasterRepository.GetByIdAsync(id);
            await _poMasterRepository.DeleteAsync(id);
            return NoContent();
        }

    }
}
